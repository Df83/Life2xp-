# Life2XP V5 — MVP

This version gives Life2XP its first usable mobile product shell:
- premium dark home dashboard
- character screen
- Strength / Cardio / Focus
- XP progression UI
- activity logging screen
- foundation for Supabase and health-data integration

Run:
1. npm install
2. npx expo start
3. Scan the QR code with Expo Go on Android.

Next development phase: authoritative XP engine + Supabase persistence + Health Connect/Apple Health.
Life2XP is independent; future game integrations must use official APIs/authorizations.
