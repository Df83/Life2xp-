import {router} from "expo-router"; import {LinearGradient} from "expo-linear-gradient";
import {Pressable,ScrollView,StyleSheet,Text,View} from "react-native";
const stats=[["STRENGTH","#B06CFF"],["CARDIO","#4ED8FF"],["FOCUS","#8DFFB2"]];
export default function Home(){return <LinearGradient colors={["#080812","#111126","#080812"]} style={s.container}>
<ScrollView contentContainerStyle={s.content}>
<View style={s.header}><View><Text style={s.kicker}>LIFE2XP</Text><Text style={s.title}>YOUR REAL LIFE</Text><Text style={s.subtitle}>LEVELS UP YOUR CHARACTER.</Text></View>
<View style={s.badge}><Text style={s.badgeSmall}>LVL</Text><Text style={s.badgeBig}>1</Text></View></View>
<View style={s.hero}><View style={s.glow}/><Text style={s.head}>◉</Text><View style={s.body}/><Text style={s.name}>NEW PLAYER</Text><Text style={s.status}>CALIBRATION • DAY 1</Text></View>
<View style={s.card}><View style={s.row}><Text style={s.label}>TOTAL XP</Text><Text style={s.xp}>0 XP</Text></View><View style={s.track}><View style={s.fill}/></View><Text style={s.muted}>300 XP to reach Level 2</Text></View>
<Text style={s.section}>PLAYER STATS</Text>{stats.map(([name,color])=><View key={name} style={s.stat}><View style={s.row}><View><Text style={[s.statName,{color}]}>{name}</Text><Text style={s.statLevel}>LEVEL 1/4</Text></View><Text style={s.xp}>0 XP</Text></View><View style={s.track}><View style={[s.fill,{backgroundColor:color,width:"0%"}]}/></View></View>)}
<Pressable style={s.primary} onPress={()=>router.push("/activity")}><Text style={s.primaryText}>+ LOG AN ACTIVITY</Text></Pressable>
<Pressable style={s.secondary} onPress={()=>router.push("/character")}><Text style={s.secondaryText}>VIEW CHARACTER</Text></Pressable>
</ScrollView></LinearGradient>}
const s=StyleSheet.create({container:{flex:1,backgroundColor:"#080812"},content:{padding:24,paddingTop:62,paddingBottom:40},
header:{flexDirection:"row",justifyContent:"space-between"},kicker:{color:"#A97BFF",fontSize:12,fontWeight:"800",letterSpacing:3},
title:{color:"#FFF",fontSize:28,fontWeight:"900",marginTop:8},subtitle:{color:"#9EA0B5",fontSize:12,fontWeight:"700",letterSpacing:2},
badge:{borderWidth:1,borderColor:"#8E67FF",borderRadius:16,padding:10,alignItems:"center",minWidth:58},badgeSmall:{color:"#A97BFF",fontSize:9,fontWeight:"800"},badgeBig:{color:"#FFF",fontSize:24,fontWeight:"900"},
hero:{marginTop:28,height:250,borderRadius:28,backgroundColor:"#11111F",borderWidth:1,borderColor:"#262640",alignItems:"center",justifyContent:"center",overflow:"hidden"},
glow:{position:"absolute",width:190,height:190,borderRadius:95,backgroundColor:"#3C1E68",opacity:.45},head:{color:"#C7A6FF",fontSize:76},body:{width:110,height:88,borderRadius:45,backgroundColor:"#6D4CB3",marginTop:-8},
name:{color:"#FFF",fontSize:18,fontWeight:"900",marginTop:8,letterSpacing:2},status:{color:"#777B98",fontSize:10,fontWeight:"700",marginTop:5,letterSpacing:1.5},
card:{marginTop:16,backgroundColor:"#151526",borderRadius:20,padding:18,borderWidth:1,borderColor:"#27273F"},row:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
label:{color:"#8F91A8",fontSize:11,fontWeight:"800",letterSpacing:1.5},xp:{color:"#FFF",fontSize:16,fontWeight:"900"},track:{height:7,backgroundColor:"#29293C",borderRadius:8,overflow:"hidden",marginTop:12},
fill:{height:"100%",backgroundColor:"#A66BFF",borderRadius:8,width:"0%"},muted:{color:"#777A92",fontSize:11,marginTop:8},section:{color:"#FFF",fontSize:13,fontWeight:"900",letterSpacing:2,marginTop:28,marginBottom:10},
stat:{backgroundColor:"#121220",borderRadius:18,padding:16,borderWidth:1,borderColor:"#25253A",marginBottom:10},statName:{fontSize:12,fontWeight:"900",letterSpacing:1.5},statLevel:{color:"#777A92",fontSize:10,fontWeight:"700",marginTop:4},
primary:{marginTop:18,backgroundColor:"#A66BFF",paddingVertical:17,borderRadius:16,alignItems:"center"},primaryText:{color:"#FFF",fontSize:13,fontWeight:"900",letterSpacing:1},
secondary:{marginTop:10,paddingVertical:16,borderRadius:16,alignItems:"center",borderWidth:1,borderColor:"#35354E"},secondaryText:{color:"#B5B6C9",fontSize:12,fontWeight:"800",letterSpacing:1}});