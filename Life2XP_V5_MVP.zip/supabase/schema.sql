create table if not exists player_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text, total_xp integer not null default 0,
 strength_xp integer not null default 0, cardio_xp integer not null default 0,
 focus_xp integer not null default 0,
 strength_condition numeric not null default 100, cardio_condition numeric not null default 100,
 focus_condition numeric not null default 100,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists activity_events (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 activity_type text not null, duration_minutes integer not null check(duration_minutes>0),
 intensity text, xp_awarded integer not null default 0, created_at timestamptz not null default now()
);
alter table player_profiles enable row level security;
alter table activity_events enable row level security;
create policy "profiles own data" on player_profiles for all using(auth.uid()=id) with check(auth.uid()=id);
create policy "activities own data" on activity_events for all using(auth.uid()=user_id) with check(auth.uid()=user_id);
